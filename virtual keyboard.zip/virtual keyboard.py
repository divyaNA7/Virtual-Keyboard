import tkinter as tk
from tkinter import *
root=tk.Tk()
root.geometry("1450x5020")
root.title("Virtual Keyboard")

#fixing window size
root.maxsize(width=1450,height=520)
root.minsize(width=1450,height=520)

#keywords
key=StringVar()
operator = ""

def clickbut(number):
    global operator
    operator=operator+str(number)
    key.set(operator)

def total():
    global operator
    add=str(eval(operator))
    key.set(add)
    operator=""

# Enter Button Work Next line Function
def enter():
   global exp
   exp = " "
   key.set(exp)


#backspace button
def backspace():
    global operator
    operator = ""
    key.set("")

#clickbut
def clickbut(number):
    global operator
    operator=operator+str(number)
    key.set(operator)


def shift_left():
    position = display.index(INSERT)
    # Changing position of cursor one character left
    display.icursor(position - 1)

def shift_right():
    position = display.index(INSERT)
    # Changing position of cursor one character right
    display.icursor(position + 1)


#display entry
display=Entry(root,textvariable=key,bd=7,width=13,font="Arial 30",bg="#7B67FC")
display.grid(ipadx = 575 , ipady = 40)

#first line buttons
b = Button(root,text="~",height=4,width=8,bd=4,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("~"))
b.place(x=15,y=150)
b1 = Button(root,text="!",height=4,width=10,bd=4,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("!"))
b1.place(x=75,y=150)
b2 = Button(root,text="@",height=4,width=10,bd=4,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("@"))
b2.place(x=150,y=150)
b3= Button(root,text="#",height=4,width=10,bd=4,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("#"))
b3.place(x=225,y=150)
b4= Button(root,text="$",height=4,width=10,bd=4,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("$"))
b4.place(x=300,y=150)
b5= Button(root,text="%",height=4,width=10,bd=4,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("%"))
b5.place(x=375,y=150)
b6= Button(root,text="^",height=4,width=10,bd=4,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("^"))
b6.place(x=450,y=150)
b7= Button(root,text="&",height=4,width=10,bd=4,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("&"))
b7.place(x=525,y=150)
b8= Button(root,text="*",height=4,width=10,bd=4,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("*"))
b8.place(x=600,y=150)
b9= Button(root,text="(",height=4,width=10,bd=4,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("("))
b9.place(x=675,y=150)
b10= Button(root,text=")",height=4,width=10,bd=4,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut(")"))
b10.place(x=750,y=150)
b11= Button(root,text="-",height=4,width=10,bd=4,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("-"))
b11.place(x=825,y=150)
b12= Button(root,text="=",height=4,width=10,bd=4,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("="))
b12.place(x=900,y=150)
b13= Button(root,text="<Backspace",height=4,width=19,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=backspace)
b13.place(x=975,y=150)
b64= Button(root,text="Num Lock",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut(""))
b64.place(x=1125,y=150)
b65= Button(root,text="/",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("/"))
b65.place(x=1200,y=150)
b66= Button(root,text="*",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("*"))
b66.place(x=1275,y=150)
b67= Button(root,text="-",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("-"))
b67.place(x=1350,y=150)

#second line buttons
b15= Button(root,text="Tab",height=4,width=12,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("    "))
b15.place(x=15,y=221)
b16= Button(root,text="Q",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("Q"))
b16.place(x=99,y=221)
b17= Button(root,text="W",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("W"))
b17.place(x=173,y=221)
b18= Button(root,text="E",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("E"))
b18.place(x=238,y=221)
b19= Button(root,text="R",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("R"))
b19.place(x=315,y=221)
b20= Button(root,text="T",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("T"))
b20.place(x=393,y=221)
b21= Button(root,text="Y",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("Y"))
b21.place(x=472,y=221)
b22= Button(root,text="U",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("U"))
b22.place(x=551,y=221)
b23= Button(root,text="I",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("I"))
b23.place(x=630,y=221)
b24= Button(root,text="O",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("O"))
b24.place(x=709,y=221)
b25= Button(root,text="P",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("P"))
b25.place(x=788,y=221)
b26= Button(root,text="[",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("["))
b26.place(x=866,y=221)
b27= Button(root,text="]",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("]"))
b27.place(x=944,y=221)
b28= Button(root,text="|",height=4,width=12,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("|"))
b28.place(x=1024,y=221)
b68= Button(root,text="7",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("7"))
b68.place(x=1125,y=221)
b69= Button(root,text="8",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("8"))
b69.place(x=1200,y=221)
b70= Button(root,text="9",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("9"))
b70.place(x=1275,y=221)

#third line
b29= Button(root,text="Capslock",height=4,width=15,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut())
b29.place(x=15,y=290)
b30= Button(root,text="A",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("A"))
b30.place(x=130,y=290)
b31= Button(root,text="S",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("S"))
b31.place(x=210,y=290)
b32= Button(root,text="D",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("D"))
b32.place(x=290,y=290)
b33= Button(root,text="F",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("F"))
b33.place(x=370,y=290)
b34= Button(root,text="G",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("G"))
b34.place(x=450,y=290)
b35= Button(root,text="H",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("H"))
b35.place(x=530,y=290)
b36= Button(root,text="J",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("J"))
b36.place(x=610,y=290)
b37= Button(root,text="K",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("K"))
b37.place(x=690,y=290)
b38= Button(root,text="L",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("L"))
b38.place(x=770,y=290)
b39= Button(root,text=";",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut(";"))
b39.place(x=850,y=290)
b40= Button(root,text="'",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("'"))
b40.place(x=930,y=290)
b41= Button(root,text="Enter",height=4,width=14,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=enter)
b41.place(x=1010,y=290)
b71= Button(root,text="4",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("4"))
b71.place(x=1125,y=290)
b72= Button(root,text="5",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("5"))
b72.place(x=1200,y=290)
b73= Button(root,text="6",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("6"))
b73.place(x=1275,y=290)

#fourth line
b42 = Button(root,text="SHIFT",height=4,width=23,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut(""))
b42.place(x=15,y=360)
b43 = Button(root,text="Z",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("Z"))
b43.place(x=168,y=360)
b44= Button(root,text="X",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("X"))
b44.place(x=246,y=360)
b45= Button(root,text="C",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("C"))
b45.place(x=324,y=360)
b46= Button(root,text="V",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("V"))
b46.place(x=402,y=360)
b47= Button(root,text="B",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("B"))
b47.place(x=480,y=360)
b48= Button(root,text="N",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("N"))
b48.place(x=560,y=360)
b49= Button(root,text="M",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("M"))
b49.place(x=639,y=360)
b50= Button(root,text=",",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut(","))
b50.place(x=717,y=360)
b51= Button(root,text=".",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("."))
b51.place(x=795,y=360)
b52= Button(root,text="?",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("?"))
b52.place(x=871,y=360)
b53= Button(root,text="SHIFT",height=4,width=23,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut(""))
b53.place(x=947,y=360)
b74= Button(root,text="1",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("1"))
b74.place(x=1125,y=360)
b75= Button(root,text="2",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("2"))
b75.place(x=1200,y=360)
b76= Button(root,text="3",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("3"))
b76.place(x=1275,y=360)

#fifth line
b54 = Button(root,text="CTRL",height=4,width=12,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut(""))
b54.place(x=15,y=430)
b55 = Button(root,text="WIN",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut(""))
b55.place(x=107,y=430)
b56= Button(root,text="ALT",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut(""))
b56.place(x=185,y=430)
b57= Button(root,text="",height=4,width=70,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut(" "))
b57.place(x=263,y=430)
b58= Button(root,text="ALT",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut(""))
b58.place(x=762,y=430)
b59= Button(root,text="CTRL",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut(""))
b59.place(x=841,y=430)
b60= Button(root,text="L",height=4,width=8,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=shift_left)
b60.place(x=915,y=430)
b61= Button(root,text="UP",height=2,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut(""))
b61.place(x=980,y=430)
b62= Button(root,text="DOWN",height=2,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut(""))
b62.place(x=980,y=460)
b63= Button(root,text="R",height=4,width=8,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=shift_right)
b63.place(x=1052,y=430)
b77= Button(root,text="0",height=4,width=21,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("0"))
b77.place(x=1125,y=430)
b78= Button(root,text=".",height=4,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("."))
b78.place(x=1275,y=430)
b79= Button(root,text="+",height=10,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=lambda:clickbut("+"))
b79.place(x=1350,y=215)
b80= Button(root,text="ENTER",height=9,width=10,bd=3,bg="#BF3EFF",activebackground="#551A8B",command=total)
b80.place(x=1350,y=355)


root.mainloop()
